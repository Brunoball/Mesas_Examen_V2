// src/components/Mesas_examen/modales/agregar_numero/ModalAgregarNumeroGrupo.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faPlus, faSearch, faSpinner, faTimes } from "@fortawesome/free-solid-svg-icons";
import "./agregar_numero.css";
import TextoExpandibleGlobal from "../../../Global/Modales/TextoExpandibleGlobal";

const texto = (valor, fallback = "-") => {
  const salida = String(valor ?? "").trim();
  return salida || fallback;
};

const normalizar = (valor) => String(valor || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

const coincide = (item, busqueda, campos) => {
  const q = normalizar(busqueda);
  if (!q) return true;
  return campos.some((campo) => normalizar(item?.[campo]).includes(q));
};

const NO_AGRUPADAS_GRID_COLS = "0.75fr 0.6fr 1.55fr 1.3fr 1.05fr 0.75fr";
const PREVIAS_GRID_COLS = "0.75fr 0.9fr 1.45fr 1.45fr 0.95fr 1.25fr";
const COLUMNAS_CENTRADAS = new Set(["seleccionar", "numero", "dni", "alumno", "alumnos", "curso"]);

const itemKeyNoAgrupada = (item) => `no-${item?.numero_mesa}`;
const itemKeyPrevia = (item) => `previa-${item?.id_previa}`;

const obtenerValidacionNoAgrupada = (item) => {
  const errores = Array.isArray(item?.validacion?.errores) ? item.validacion.errores.filter(Boolean) : [];
  const erroresReales = errores.filter((error) => !normalizar(error).includes("area"));
  const validoBackend = item?.validacion?.valido !== false || erroresReales.length === 0;
  const agregable = item?.agregable !== false && validoBackend;
  const titulo = agregable
    ? "Seleccionar número"
    : (erroresReales.length ? erroresReales.join(" ") : "Este número tiene conflictos y no se puede agregar al grupo.");

  return { agregable, titulo };
};

const isTopMesaModal = (node) => {
  if (typeof document === "undefined" || !node) return true;
  const modales = Array.from(document.querySelectorAll("[data-mesa-modal-root='true'], .gdel-overlay, [data-global-info-modal-root='true']"));
  return modales[modales.length - 1] === node;
};

const useEscapeClose = (abierto, onClose, disabled = false) => {
  const overlayRef = useRef(null);

  useEffect(() => {
    if (!abierto) return undefined;

    const handleKeyDown = (event) => {
      if (event.key !== "Escape" || disabled) return;
      if (!isTopMesaModal(overlayRef.current)) return;

      event.preventDefault();
      event.stopPropagation();
      onClose?.();
    };

    document.addEventListener("keydown", handleKeyDown, true);
    return () => document.removeEventListener("keydown", handleKeyDown, true);
  }, [abierto, onClose, disabled]);

  return overlayRef;
};

const GridHead = ({ columns, gridCols }) => (
  <div className="ag-num-grid-row ag-num-grid-head" style={{ gridTemplateColumns: gridCols }} role="row">
    {columns.map((column) => (
      <div
        key={column.key}
        className={`ag-num-grid-cell ag-num-grid-cell-head ${COLUMNAS_CENTRADAS.has(column.key) ? "ag-num-center" : ""}`}
        role="columnheader"
      >
        {column.label}
      </div>
    ))}
  </div>
);


const AgNumTableSkeleton = ({ columns, gridCols, rows = 4 }) => (
  <div className="ag-num-table-wrap ag-num-table-wrap-skeleton" aria-hidden="true">
    <div className="ag-num-table ag-num-div-table ag-num-table-skeleton" role="presentation">
      <GridHead columns={columns} gridCols={gridCols} />
      <div className="ag-num-grid-body" role="presentation">
        {Array.from({ length: rows }).map((_, rowIndex) => (
          <div
            key={`ag-num-skeleton-row-${rowIndex}`}
            className="ag-num-grid-row ag-num-grid-data-row ag-num-grid-skeleton-row"
            style={{ gridTemplateColumns: gridCols }}
            role="presentation"
          >
            {columns.map((column, colIndex) => (
              <div key={`${column.key}-${colIndex}`} className={`ag-num-grid-cell ${COLUMNAS_CENTRADAS.has(column.key) ? "ag-num-center" : ""}`} role="presentation">
                <span className={`ag-num-skeleton-line ag-num-skeleton-line--${column.key}`} />
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  </div>
);

const SelectorFila = ({ activo, disabled, title, ariaLabel, onSelect }) => (
  <button
    type="button"
    className={`ag-num-radio ${activo ? "activo" : ""}`}
    disabled={disabled}
    title={title}
    aria-label={ariaLabel}
    aria-pressed={activo}
    onClick={(event) => {
      event.stopPropagation();
      onSelect?.();
    }}
  >
    {activo && <FontAwesomeIcon icon={faCheck} />}
  </button>
);

const FilaNoAgrupada = ({ item, agregando, seleccionado, onSelect }) => {
  const { agregable, titulo } = obtenerValidacionNoAgrupada(item);
  const puedeSeleccionar = agregable && !agregando;

  const seleccionar = () => {
    if (!puedeSeleccionar) return;
    onSelect?.(item);
  };

  return (
    <div
      className={`ag-num-grid-row ag-num-grid-data-row ${puedeSeleccionar ? "ag-num-row-selectable" : "ag-num-row-disabled"} ${seleccionado ? "ag-num-row-selected" : ""}`}
      style={{ gridTemplateColumns: NO_AGRUPADAS_GRID_COLS }}
      role="row"
      tabIndex={puedeSeleccionar ? 0 : -1}
      aria-selected={seleccionado}
      title={!puedeSeleccionar ? titulo : undefined}
      onClick={seleccionar}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          seleccionar();
        }
      }}
    >
      <div className="ag-num-grid-cell ag-num-center ag-num-grid-actions" role="cell" data-label="Seleccionar">
        <SelectorFila
          activo={seleccionado}
          disabled={!puedeSeleccionar}
          title={seleccionado ? "Deseleccionar número" : titulo}
          ariaLabel={`${seleccionado ? "Deseleccionar" : "Seleccionar"} mesa N° ${texto(item.numero_mesa)}`}
          onSelect={seleccionar}
        />
      </div>
      <div className="ag-num-grid-cell ag-num-center" role="cell" data-label="N° mesa">N° {texto(item.numero_mesa)}</div>
      <div className="ag-num-grid-cell is-strong" role="cell" data-label="Materia">
        <TextoExpandibleGlobal value={item.materia} fallback="Sin materia" title="Materia" subtitle={`Mesa N° ${texto(item.numero_mesa)}`} />
      </div>
      <div className="ag-num-grid-cell" role="cell" data-label="Docente">
        <TextoExpandibleGlobal value={item.docente} fallback="Sin docente" title="Docente" subtitle={`DNI ${texto(item.dni)}`} />
      </div>
      <div className="ag-num-grid-cell" role="cell" data-label="Área">
        <TextoExpandibleGlobal value={item.area} fallback="Sin área" title="Área" subtitle={`Mesa N° ${texto(item.numero_mesa)}`} />
      </div>
      <div className="ag-num-grid-cell ag-num-center" role="cell" data-label="Alumnos">{texto(item.cantidad_alumnos, "0")}</div>
    </div>
  );
};

const FilaPrevia = ({ item, agregando, seleccionado, onSelect }) => {
  const puedeSeleccionar = !agregando;
  const seleccionar = () => {
    if (!puedeSeleccionar) return;
    onSelect?.(item);
  };

  return (
    <div
      className={`ag-num-grid-row ag-num-grid-data-row ${puedeSeleccionar ? "ag-num-row-selectable" : "ag-num-row-disabled"} ${seleccionado ? "ag-num-row-selected" : ""}`}
      style={{ gridTemplateColumns: PREVIAS_GRID_COLS }}
      role="row"
      tabIndex={puedeSeleccionar ? 0 : -1}
      aria-selected={seleccionado}
      onClick={seleccionar}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          seleccionar();
        }
      }}
    >
      <div className="ag-num-grid-cell ag-num-center ag-num-grid-actions" role="cell" data-label="Seleccionar">
        <SelectorFila
          activo={seleccionado}
          disabled={!puedeSeleccionar}
          title={seleccionado ? "Deseleccionar previa" : "Seleccionar previa"}
          ariaLabel={`${seleccionado ? "Deseleccionar" : "Seleccionar"} previa de ${texto(item.alumno)}`}
          onSelect={seleccionar}
        />
      </div>
      <div className="ag-num-grid-cell ag-num-center" role="cell" data-label="DNI">{texto(item.dni)}</div>
      <div className="ag-num-grid-cell is-strong ag-num-center" role="cell" data-label="Alumno">
        <TextoExpandibleGlobal value={item.alumno} title="Alumno" subtitle={`DNI ${texto(item.dni)}`} />
      </div>
      <div className="ag-num-grid-cell" role="cell" data-label="Materia">
        <TextoExpandibleGlobal value={item.materia} title="Materia" subtitle={`DNI ${texto(item.dni)}`} />
      </div>
      <div className="ag-num-grid-cell ag-num-center" role="cell" data-label="Curso / Div.">{texto(item.curso)}</div>
      <div className="ag-num-grid-cell" role="cell" data-label="Docente">
        <TextoExpandibleGlobal value={item.docente} fallback="Sin docente" title="Docente" subtitle={`Mesa N° ${texto(item.numero_mesa)}`} />
      </div>
    </div>
  );
};

const ModalAgregarNumeroGrupo = ({ abierto, data, cargando, agregando, error, onClose, onAgregar }) => {
  const [tab, setTab] = useState("no_agrupadas");
  const [busqueda, setBusqueda] = useState("");
  const [seleccionActual, setSeleccionActual] = useState(null);
  const overlayRef = useEscapeClose(abierto, onClose, agregando);

  const noAgrupadas = useMemo(() => {
    const lista = Array.isArray(data?.no_agrupadas) ? data.no_agrupadas : [];
    return lista.filter((item) => coincide(item, busqueda, ["numero_mesa", "materia", "docente", "area", "alumnos_texto"]));
  }, [data, busqueda]);

  const previas = useMemo(() => {
    const lista = Array.isArray(data?.previas_sin_mesa) ? data.previas_sin_mesa : [];
    return lista.filter((item) => coincide(item, busqueda, ["dni", "alumno", "materia", "curso", "docente", "area"]));
  }, [data, busqueda]);

  useEffect(() => {
    if (!abierto) {
      setSeleccionActual(null);
      setBusqueda("");
      setTab("no_agrupadas");
    }
  }, [abierto]);

  useEffect(() => {
    if (!abierto) return;
    setSeleccionActual(null);
  }, [abierto, data?.meta?.numero_grupo, data?.meta?.fecha, data?.meta?.turno]);

  if (!abierto) return null;

  const portalTarget = typeof document !== "undefined" ? document.body : null;
  if (!portalTarget) return null;

  const meta = data?.meta || {};
  const tipoActual = tab === "no_agrupadas" ? "no_agrupada" : "previa_sin_mesa";
  const placeholder = tab === "no_agrupadas"
    ? "Buscar por número, materia, docente, alumno..."
    : "Buscar por DNI, alumno, materia, curso...";

  const seleccionVisible = (() => {
    if (!seleccionActual || seleccionActual.tipo !== tipoActual) return null;
    const lista = tab === "no_agrupadas" ? noAgrupadas : previas;
    const makeKey = tab === "no_agrupadas" ? itemKeyNoAgrupada : itemKeyPrevia;
    const item = lista.find((actual) => makeKey(actual) === seleccionActual.key) || null;
    if (!item) return null;
    if (tab === "no_agrupadas" && !obtenerValidacionNoAgrupada(item).agregable) return null;
    return { ...seleccionActual, item };
  })();

  const puedeConfirmar = !!seleccionVisible && !agregando && !cargando && typeof onAgregar === "function";

  const seleccionarNoAgrupada = (item) => {
    const key = itemKeyNoAgrupada(item);
    setSeleccionActual((actual) => (actual?.key === key ? null : { tipo: "no_agrupada", key, item }));
  };

  const seleccionarPrevia = (item) => {
    const key = itemKeyPrevia(item);
    setSeleccionActual((actual) => (actual?.key === key ? null : { tipo: "previa_sin_mesa", key, item }));
  };

  const confirmarSeleccion = () => {
    if (!puedeConfirmar) return;
    Promise.resolve(onAgregar(seleccionVisible.item, seleccionVisible.tipo)).catch(() => {});
  };

  const cambiarTab = (nuevoTab) => {
    setTab(nuevoTab);
    setSeleccionActual(null);
  };

  const columnsNoAgrupadas = [
    { key: "seleccionar", label: "Seleccionar" },
    { key: "numero", label: "N° mesa" },
    { key: "materia", label: "Materia" },
    { key: "docente", label: "Docente" },
    { key: "area", label: "Área" },
    { key: "alumnos", label: "Alumnos" },
  ];

  const columnsPrevias = [
    { key: "seleccionar", label: "Seleccionar" },
    { key: "dni", label: "DNI" },
    { key: "alumno", label: "Alumno" },
    { key: "materia", label: "Materia" },
    { key: "curso", label: "Curso / Div." },
    { key: "docente", label: "Docente" },
  ];

  return createPortal((
    <div ref={overlayRef} className="ag-num-overlay" role="dialog" aria-modal="true" data-mesa-modal-root="true">
      <div className={`ag-num-panel ${cargando ? "is-loading" : ""}`}>
        <header className="ag-num-header">
          <div className="ag-num-header-title">
            <span className="ag-num-header-icon" aria-hidden="true">
              <FontAwesomeIcon icon={faPlus} />
            </span>
            <div className="ag-num-header-text">
              <h2>Agregar número al grupo</h2>
              <div className="ag-num-header-meta">
                <span>Grupo <strong>{texto(meta.numero_grupo)}</strong></span>
                <span>Fecha <strong>{texto(meta.fecha)}</strong></span>
                <span>Turno <strong>{texto(meta.turno)}</strong></span>
                <span>Libres <strong>{texto(meta.slots_libres, "0")}</strong></span>
              </div>
            </div>
          </div>
          <button type="button" className="mesa-submodal-close" onClick={onClose} disabled={agregando} aria-label="Cerrar">
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </header>

        <div className="ag-num-tabs">
          <button
            type="button"
            className={tab === "no_agrupadas" ? "active" : ""}
            onClick={() => cambiarTab("no_agrupadas")}
          >
            Mesas no agrupadas
          </button>
          <button
            type="button"
            className={tab === "previas" ? "active" : ""}
            onClick={() => cambiarTab("previas")}
          >
            Previas sin número de mesa
          </button>
        </div>

        <section className="ag-num-content">
          <label className="ag-num-search">
            <FontAwesomeIcon icon={faSearch} />
            <input
              type="text"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              placeholder={placeholder}
            />
          </label>

          {error ? (
            <div className="ag-num-error">{error}</div>
          ) : null}

          {cargando ? (
            <AgNumTableSkeleton
              columns={tab === "no_agrupadas" ? columnsNoAgrupadas : columnsPrevias}
              gridCols={tab === "no_agrupadas" ? NO_AGRUPADAS_GRID_COLS : PREVIAS_GRID_COLS}
              rows={4}
            />
          ) : (tab === "no_agrupadas" ? (
            noAgrupadas.length === 0 ? (
              <div className="ag-num-empty">No hay mesas no agrupadas disponibles.</div>
            ) : (
              <div className="ag-num-table-wrap">
                <div className="ag-num-table ag-num-div-table" role="table" aria-label="Mesas no agrupadas disponibles">
                  <GridHead columns={columnsNoAgrupadas} gridCols={NO_AGRUPADAS_GRID_COLS} />
                  <div className="ag-num-grid-body" role="rowgroup">
                    {noAgrupadas.map((item) => {
                      const key = itemKeyNoAgrupada(item);
                      return (
                        <FilaNoAgrupada
                          key={key}
                          item={item}
                          agregando={agregando}
                          seleccionado={seleccionVisible?.key === key}
                          onSelect={seleccionarNoAgrupada}
                        />
                      );
                    })}
                  </div>
                </div>
              </div>
            )
          ) : previas.length === 0 ? (
            <div className="ag-num-empty">No hay previas sin número de mesa disponibles para este día y turno.</div>
          ) : (
            <div className="ag-num-table-wrap">
              <div className="ag-num-table ag-num-div-table" role="table" aria-label="Previas sin número de mesa">
                <GridHead columns={columnsPrevias} gridCols={PREVIAS_GRID_COLS} />
                <div className="ag-num-grid-body" role="rowgroup">
                  {previas.map((item) => {
                    const key = itemKeyPrevia(item);
                    return (
                      <FilaPrevia
                        key={key}
                        item={item}
                        agregando={agregando}
                        seleccionado={seleccionVisible?.key === key}
                        onSelect={seleccionarPrevia}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </section>

        <footer className="ag-num-footer">
          <button type="button" className="mesa-submodal-footer-close" onClick={onClose} disabled={agregando}>Cerrar</button>
          <button
            type="button"
            className="ag-num-confirm-btn"
            onClick={confirmarSeleccion}
            disabled={!puedeConfirmar}
          >
            <FontAwesomeIcon icon={agregando ? faSpinner : faPlus} spin={agregando} />
            Confirmar
          </button>
        </footer>
      </div>
    </div>
  ), portalTarget);
};

export default ModalAgregarNumeroGrupo;
