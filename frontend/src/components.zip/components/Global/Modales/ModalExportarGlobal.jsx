import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFileExcel, faFilePdf, faLayerGroup, faList, faSpinner, faTimes } from "@fortawesome/free-solid-svg-icons";
import "../Global_css/Global_Modals.css";
import "../Global_css/Global_ExportarHistorial.css";

const FORMATOS_EXPORTAR = [
  {
    value: "excel",
    label: "Excel",
    description: "Descarga directa en archivo .xls.",
    icon: faFileExcel,
    tone: "excel",
  },
  {
    value: "pdf",
    label: "PDF",
    description: "Descarga directa en archivo .pdf.",
    icon: faFilePdf,
    tone: "pdf",
  },
];

const ALCANCE_ACTUAL = "actual";
const ALCANCE_TODOS = "todos";

function normalizarTexto(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "boolean") return value ? "Sí" : "No";

  return String(value)
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\s+/g, " ")
    .trim();
}

function escapeHtml(value) {
  return normalizarTexto(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function slugify(value, fallback = "exportacion") {
  const slug = String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);

  return slug || fallback;
}

function fechaArchivo() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}`;
}

function descargarBlob(blob, nombreArchivo) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = nombreArchivo;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => window.URL.revokeObjectURL(url), 500);
}

function resolverValor(columna, registro, index) {
  if (typeof columna?.value === "function") return columna.value(registro, index);
  if (columna?.key) return registro?.[columna.key];
  return "";
}

function normalizarColumnas(columnas = []) {
  return (Array.isArray(columnas) ? columnas : [])
    .filter(Boolean)
    .map((columna) => ({
      label: normalizarTexto(columna.label || columna.header || columna.key),
      key: columna.key,
      value: columna.value,
    }))
    .filter((columna) => columna.label);
}

function normalizarSecciones(secciones = []) {
  return (Array.isArray(secciones) ? secciones : [])
    .map((seccion) => ({
      titulo: normalizarTexto(seccion?.titulo || seccion?.title || "Registros"),
      subtitulo: normalizarTexto(seccion?.subtitulo || seccion?.subtitle || ""),
      columnas: normalizarColumnas(seccion?.columnas || seccion?.columns || []),
      registros: Array.isArray(seccion?.registros || seccion?.rows) ? (seccion.registros || seccion.rows) : [],
    }))
    .filter((seccion) => seccion.columnas.length > 0);
}

function contarRegistrosSecciones(secciones = []) {
  return normalizarSecciones(secciones).reduce((acc, seccion) => acc + seccion.registros.length, 0);
}

function crearSeccionUnica({ titulo, subtitulo, columnas, registros }) {
  return [{
    titulo: titulo || "Registros",
    subtitulo: subtitulo || "",
    columnas: columnas || [],
    registros: Array.isArray(registros) ? registros : [],
  }];
}

function crearTablaHtml({ columnas, registros }) {
  const cols = normalizarColumnas(columnas);

  const thead = cols
    .map((columna) => `<th>${escapeHtml(columna.label)}</th>`)
    .join("");

  const tbody = (Array.isArray(registros) ? registros : [])
    .map((registro, index) => {
      const celdas = cols
        .map((columna) => `<td>${escapeHtml(resolverValor(columna, registro, index))}</td>`)
        .join("");
      return `<tr>${celdas}</tr>`;
    })
    .join("");

  return `<table><thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody></table>`;
}

function exportarExcel({ titulo, subtitulo, secciones, nombreArchivo }) {
  const bloques = secciones.map((seccion) => `
    <section>
      <h2>${escapeHtml(seccion.titulo)}</h2>
      ${seccion.subtitulo ? `<p>${escapeHtml(seccion.subtitulo)}</p>` : ""}
      ${crearTablaHtml({ columnas: seccion.columnas, registros: seccion.registros })}
    </section>
  `).join('<br style="page-break-after:always;" />');

  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body{font-family:Arial, sans-serif;color:#222;}
    h1{font-size:20px;margin:0 0 6px;color:#3A2E2B;}
    h2{font-size:17px;margin:18px 0 6px;color:#3A2E2B;}
    p{margin:0 0 12px;color:#555;font-weight:600;}
    table{border-collapse:collapse;width:100%;margin-bottom:18px;}
    th,td{border:1px solid #cfd8e3;padding:7px 9px;mso-number-format:'\\@';vertical-align:top;}
    th{background:#3A2E2B;color:#fff;font-weight:700;}
  </style>
</head>
<body>
  <h1>${escapeHtml(titulo)}</h1>
  ${subtitulo ? `<p>${escapeHtml(subtitulo)}</p>` : ""}
  ${bloques}
</body>
</html>`;

  const blob = new Blob([`\ufeff${html}`], { type: "application/vnd.ms-excel;charset=utf-8;" });
  descargarBlob(blob, `${slugify(nombreArchivo || titulo)}_${fechaArchivo()}.xls`);
}

function pdfString(value) {
  const text = normalizarTexto(value)
    .replace(/\t/g, " ")
    .replace(/[^\x20-\x7E\xA0-\xFF]/g, "?");

  let out = "";
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    const code = ch.charCodeAt(0);
    if (ch === "(" || ch === ")" || ch === "\\") {
      out += `\\${ch}`;
    } else if (code < 32) {
      out += " ";
    } else if (code > 126) {
      out += `\\${code.toString(8).padStart(3, "0")}`;
    } else {
      out += ch;
    }
  }
  return out;
}

function dividirTextoPdf(texto, maxChars, maxLineas = 3) {
  const limpio = normalizarTexto(texto);
  if (!limpio) return ["-"];

  const palabras = limpio.split(" ");
  const lineas = [];
  let linea = "";

  palabras.forEach((palabra) => {
    const candidata = linea ? `${linea} ${palabra}` : palabra;
    if (candidata.length <= maxChars) {
      linea = candidata;
      return;
    }

    if (linea) lineas.push(linea);

    if (palabra.length > maxChars) {
      let resto = palabra;
      while (resto.length > maxChars) {
        lineas.push(resto.slice(0, maxChars));
        resto = resto.slice(maxChars);
      }
      linea = resto;
    } else {
      linea = palabra;
    }
  });

  if (linea) lineas.push(linea);

  if (lineas.length <= maxLineas) return lineas;

  const recortadas = lineas.slice(0, maxLineas);
  recortadas[maxLineas - 1] = `${recortadas[maxLineas - 1].slice(0, Math.max(0, maxChars - 1))}…`;
  return recortadas;
}

function crearPaginasPdf({ titulo, subtitulo, secciones }) {
  const pageWidth = 841.89;
  const pageHeight = 595.28;
  const margin = 28;
  const bottomMargin = 34;
  const usableWidth = pageWidth - margin * 2;
  const pages = [];
  let commands = [];
  let y = pageHeight - margin;
  let pageNumber = 0;

  const addText = (text, x, currentY, size = 9, bold = false) => {
    commands.push(`BT /${bold ? "F2" : "F1"} ${size} Tf ${x.toFixed(2)} ${currentY.toFixed(2)} Td (${pdfString(text)}) Tj ET`);
  };

  const addLine = (x1, y1, x2, y2) => {
    commands.push(`${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`);
  };

  const startPage = () => {
    commands = [];
    y = pageHeight - margin;
    pageNumber += 1;
    addText(titulo, margin, y, 15, true);
    y -= 16;
    if (subtitulo) {
      addText(subtitulo, margin, y, 9, false);
      y -= 16;
    }
    addLine(margin, y + 6, pageWidth - margin, y + 6);
    y -= 10;
  };

  const finishPage = () => {
    addLine(margin, bottomMargin - 8, pageWidth - margin, bottomMargin - 8);
    addText(`Página ${pageNumber}`, pageWidth - margin - 60, bottomMargin - 22, 8, false);
    pages.push(commands.join("\n"));
  };

  const ensureSpace = (height) => {
    if (y - height >= bottomMargin) return;
    finishPage();
    startPage();
  };

  startPage();

  normalizarSecciones(secciones).forEach((seccion, sectionIndex) => {
    ensureSpace(44);
    if (sectionIndex > 0) y -= 4;
    addText(seccion.titulo, margin, y, 12, true);
    y -= 13;
    if (seccion.subtitulo) {
      addText(seccion.subtitulo, margin, y, 8, false);
      y -= 12;
    }

    const columnas = seccion.columnas;
    const cantidadCols = Math.max(1, columnas.length);
    const colWidth = usableWidth / cantidadCols;
    const fontSize = cantidadCols >= 7 ? 6.4 : cantidadCols >= 5 ? 7.1 : 8;
    const lineHeight = fontSize + 2.2;
    const maxChars = Math.max(7, Math.floor(colWidth / (fontSize * 0.48)));

    ensureSpace(24);
    columnas.forEach((columna, colIndex) => {
      addText(columna.label, margin + colIndex * colWidth + 2, y, fontSize, true);
    });
    y -= 9;
    addLine(margin, y + 3, pageWidth - margin, y + 3);
    y -= 4;

    if (seccion.registros.length === 0) {
      ensureSpace(18);
      addText("Sin registros para exportar.", margin, y, 8, false);
      y -= 18;
      return;
    }

    seccion.registros.forEach((registro, rowIndex) => {
      const lineasPorCelda = columnas.map((columna) => dividirTextoPdf(resolverValor(columna, registro, rowIndex), maxChars, 3));
      const maxLineas = Math.max(1, ...lineasPorCelda.map((lineas) => lineas.length));
      const rowHeight = Math.max(15, maxLineas * lineHeight + 7);

      ensureSpace(rowHeight + 3);

      lineasPorCelda.forEach((lineas, colIndex) => {
        lineas.forEach((linea, lineIndex) => {
          addText(linea, margin + colIndex * colWidth + 2, y - lineIndex * lineHeight, fontSize, false);
        });
      });

      y -= rowHeight;
      addLine(margin, y + 4, pageWidth - margin, y + 4);
    });

    y -= 12;
  });

  finishPage();

  return { pages, pageWidth, pageHeight };
}

function construirPdf({ titulo, subtitulo, secciones }) {
  const { pages, pageWidth, pageHeight } = crearPaginasPdf({ titulo, subtitulo, secciones });
  const objects = [];
  const pageObjectNumbers = [];

  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";

  let nextObject = 5;
  pages.forEach((stream) => {
    const pageObj = nextObject;
    const contentObj = nextObject + 1;
    nextObject += 2;
    pageObjectNumbers.push(pageObj);
    objects[pageObj] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth.toFixed(2)} ${pageHeight.toFixed(2)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentObj} 0 R >>`;
    objects[contentObj] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  });

  objects[2] = `<< /Type /Pages /Count ${pageObjectNumbers.length} /Kids [${pageObjectNumbers.map((n) => `${n} 0 R`).join(" ")}] >>`;

  let pdf = "%PDF-1.4\n% Mesas de Examen - Exportacion\n";
  const offsets = [0];

  for (let i = 1; i < objects.length; i += 1) {
    if (!objects[i]) continue;
    offsets[i] = pdf.length;
    pdf += `${i} 0 obj\n${objects[i]}\nendobj\n`;
  }

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length}\n`;
  pdf += "0000000000 65535 f \n";
  for (let i = 1; i < objects.length; i += 1) {
    const offset = offsets[i] || 0;
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  return pdf;
}

function exportarPdf({ titulo, subtitulo, secciones, nombreArchivo }) {
  const pdf = construirPdf({ titulo, subtitulo, secciones });
  const bytes = new Uint8Array(pdf.length);
  for (let i = 0; i < pdf.length; i += 1) {
    bytes[i] = pdf.charCodeAt(i) & 0xff;
  }
  const blob = new Blob([bytes], { type: "application/pdf" });
  descargarBlob(blob, `${slugify(nombreArchivo || titulo)}_${fechaArchivo()}.pdf`);
}

function exportarDesdeModalGlobal({ formato, titulo, subtitulo, secciones, nombreArchivo }) {
  const seccionesNormalizadas = normalizarSecciones(secciones);
  const totalRegistros = contarRegistrosSecciones(seccionesNormalizadas);

  if (seccionesNormalizadas.length === 0) {
    throw new Error("No hay columnas configuradas para exportar.");
  }

  if (totalRegistros <= 0) {
    throw new Error("No hay registros para exportar.");
  }

  if (formato === "pdf") {
    exportarPdf({ titulo, subtitulo, secciones: seccionesNormalizadas, nombreArchivo });
    return;
  }

  exportarExcel({ titulo, subtitulo, secciones: seccionesNormalizadas, nombreArchivo });
}

const pluralizar = (cantidad, singular, plural) => (
  Number(cantidad) === 1 ? singular : plural
);

const ModalExportarGlobal = ({
  abierto,
  open,
  loading = false,
  disabled = false,
  title = "Exportar registros",
  subtitle = "Elegí el formato y el alcance de la exportación.",
  tituloArchivo,
  subtituloArchivoActual = "",
  subtituloArchivoTodos = "",
  nombreArchivo = "exportacion",
  columnas = [],
  registrosActuales = [],
  registrosTodos = null,
  obtenerRegistrosTodos,
  seccionesActuales = null,
  seccionesTodos = null,
  obtenerSeccionesTodos,
  cantidadActual,
  totalActual,
  cantidad,
  cantidadTodos,
  totalTodos,
  total,
  totalLabelSingular = "registro disponible",
  totalLabelPlural = "registros disponibles",
  alcanceActualLabel = "Exportar solo actual",
  alcanceActualDescription = "Descarga los registros visibles en la página actual.",
  alcanceTodosLabel = "Exportar todos los registros",
  alcanceTodosDescription = "Descarga todos los registros que coinciden con los filtros actuales.",
  mostrarAlcanceTodos = true,
  defaultFormato = "excel",
  defaultAlcance = ALCANCE_TODOS,
  confirmLabel = "Exportar",
  cancelLabel = "Cancelar",
  loadingLabel = "Exportando...",
  note = "El PDF se descarga directamente, sin abrir una ventana emergente.",
  onClose,
  onSuccess,
  onError,
}) => {
  const isOpen = Boolean(open ?? abierto);
  const [formato, setFormato] = useState(defaultFormato);
  const [alcance, setAlcance] = useState(defaultAlcance);
  const [exportando, setExportando] = useState(false);

  const seccionesActualesNormalizadas = useMemo(() => {
    if (Array.isArray(seccionesActuales)) return normalizarSecciones(seccionesActuales);
    return normalizarSecciones(crearSeccionUnica({
      titulo: tituloArchivo || title,
      subtitulo: subtituloArchivoActual,
      columnas,
      registros: registrosActuales,
    }));
  }, [columnas, registrosActuales, seccionesActuales, subtituloArchivoActual, title, tituloArchivo]);

  const seccionesTodosNormalizadas = useMemo(() => {
    if (Array.isArray(seccionesTodos)) return normalizarSecciones(seccionesTodos);
    if (Array.isArray(registrosTodos)) {
      return normalizarSecciones(crearSeccionUnica({
        titulo: tituloArchivo || title,
        subtitulo: subtituloArchivoTodos,
        columnas,
        registros: registrosTodos,
      }));
    }
    return [];
  }, [columnas, registrosTodos, seccionesTodos, subtituloArchivoTodos, title, tituloArchivo]);

  const totalActualDisponible = Number(
    cantidadActual ??
    totalActual ??
    cantidad ??
    contarRegistrosSecciones(seccionesActualesNormalizadas)
  );

  const totalTodosDisponible = Number(
    cantidadTodos ??
    totalTodos ??
    total ??
    (seccionesTodosNormalizadas.length > 0 ? contarRegistrosSecciones(seccionesTodosNormalizadas) : totalActualDisponible)
  );

  const puedeExportarTodos = mostrarAlcanceTodos && (
    Boolean(obtenerRegistrosTodos) ||
    Boolean(obtenerSeccionesTodos) ||
    seccionesTodosNormalizadas.length > 0 ||
    Array.isArray(registrosTodos) ||
    totalTodosDisponible > totalActualDisponible
  );

  const opcionesAlcance = [
    {
      value: ALCANCE_ACTUAL,
      label: alcanceActualLabel,
      description: alcanceActualDescription,
      icon: faList,
      cantidad: totalActualDisponible,
    },
    ...(puedeExportarTodos ? [{
      value: ALCANCE_TODOS,
      label: alcanceTodosLabel,
      description: alcanceTodosDescription,
      icon: faLayerGroup,
      cantidad: totalTodosDisponible,
    }] : []),
  ];

  useEffect(() => {
    if (!isOpen) return;
    setFormato(defaultFormato || "excel");
    setAlcance(puedeExportarTodos ? (defaultAlcance || ALCANCE_TODOS) : ALCANCE_ACTUAL);
  }, [defaultAlcance, defaultFormato, isOpen, puedeExportarTodos]);

  useEffect(() => {
    if (!isOpen) return undefined;

    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        if (!loading && !exportando) onClose?.();
      }
    };

    document.addEventListener("keydown", onKeyDown, true);
    return () => document.removeEventListener("keydown", onKeyDown, true);
  }, [exportando, isOpen, loading, onClose]);

  if (!isOpen) return null;

  const portalTarget = typeof document !== "undefined" ? document.body : null;
  if (!portalTarget) return null;

  const opcionFormato = FORMATOS_EXPORTAR.find((opcion) => opcion.value === formato) || FORMATOS_EXPORTAR[0];
  const opcionAlcance = opcionesAlcance.find((opcion) => opcion.value === alcance) || opcionesAlcance[0];
  const totalSeleccionado = Number(opcionAlcance?.cantidad || 0);
  const submitDisabled = loading || exportando || disabled || totalSeleccionado <= 0;

  const resolverSecciones = async () => {
    if (alcance === ALCANCE_ACTUAL) return seccionesActualesNormalizadas;

    if (typeof obtenerSeccionesTodos === "function") {
      const resultado = await obtenerSeccionesTodos();
      return normalizarSecciones(resultado);
    }

    if (seccionesTodosNormalizadas.length > 0) return seccionesTodosNormalizadas;

    if (typeof obtenerRegistrosTodos === "function") {
      const registros = await obtenerRegistrosTodos();
      return normalizarSecciones(crearSeccionUnica({
        titulo: tituloArchivo || title,
        subtitulo: subtituloArchivoTodos,
        columnas,
        registros,
      }));
    }

    return seccionesActualesNormalizadas;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (submitDisabled) return;

    setExportando(true);
    try {
      const secciones = await resolverSecciones();
      const totalExportado = contarRegistrosSecciones(secciones);
      const subtitulo = alcance === ALCANCE_TODOS ? subtituloArchivoTodos : subtituloArchivoActual;
      const sufijoNombre = alcance === ALCANCE_TODOS ? "todos" : "actual";

      exportarDesdeModalGlobal({
        formato,
        titulo: tituloArchivo || title,
        subtitulo,
        secciones,
        nombreArchivo: `${nombreArchivo}_${sufijoNombre}`,
      });

      onSuccess?.(
        formato === "pdf"
          ? `PDF descargado correctamente (${totalExportado} ${pluralizar(totalExportado, "registro", "registros")}).`
          : `Excel descargado correctamente (${totalExportado} ${pluralizar(totalExportado, "registro", "registros")}).`
      );
      onClose?.();
    } catch (error) {
      onError?.(error?.message || "No se pudo exportar la información.");
    } finally {
      setExportando(false);
    }
  };

  return createPortal((
    <div className="global-exportHistorial-overlay" role="dialog" aria-modal="true" aria-labelledby="global-exportHistorial-title">
      <form className="global-exportHistorial-modal" onSubmit={handleSubmit}>
        <header className="global-exportHistorial-header">
          <div>
            <h2 id="global-exportHistorial-title">{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>

          <button
            type="button"
            className="global-exportHistorial-close"
            onClick={onClose}
            disabled={loading || exportando}
            aria-label="Cerrar"
          >
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </header>

        <section className="global-exportHistorial-body">
          <div className="global-exportHistorial-info">
            <strong>{totalSeleccionado}</strong>
            <span>{pluralizar(totalSeleccionado, totalLabelSingular, totalLabelPlural)}</span>
          </div>

          {note ? <p className="global-exportHistorial-note">{note}</p> : null}

          <div className="global-exportHistorial-groupTitle">Alcance</div>
          <div className="global-exportHistorial-options global-exportHistorial-options--scope" role="radiogroup" aria-label="Alcance de exportación">
            {opcionesAlcance.map((opcion) => {
              const isActive = alcance === opcion.value;
              return (
                <label key={opcion.value} className={`global-exportHistorial-option ${isActive ? "is-active" : ""}`}>
                  <input
                    type="radio"
                    name="alcance_exportar_global"
                    value={opcion.value}
                    checked={isActive}
                    disabled={loading || exportando}
                    onChange={() => setAlcance(opcion.value)}
                  />
                  <span className="global-exportHistorial-icon is-scope">
                    <FontAwesomeIcon icon={opcion.icon} />
                  </span>
                  <span>
                    <b>{opcion.label}</b>
                    <small>{opcion.description}</small>
                    <small>{opcion.cantidad} {pluralizar(opcion.cantidad, "registro", "registros")}</small>
                  </span>
                </label>
              );
            })}
          </div>

          <div className="global-exportHistorial-groupTitle">Formato</div>
          <div className="global-exportHistorial-options" role="radiogroup" aria-label="Formato de exportación">
            {FORMATOS_EXPORTAR.map((opcion) => {
              const isActive = formato === opcion.value;
              return (
                <label key={opcion.value} className={`global-exportHistorial-option ${isActive ? "is-active" : ""}`}>
                  <input
                    type="radio"
                    name="formato_exportar_global"
                    value={opcion.value}
                    checked={isActive}
                    disabled={loading || exportando}
                    onChange={() => setFormato(opcion.value)}
                  />
                  <span className={`global-exportHistorial-icon is-${opcion.tone}`}>
                    <FontAwesomeIcon icon={opcion.icon} />
                  </span>
                  <span>
                    <b>{opcion.label}</b>
                    <small>{opcion.description}</small>
                  </span>
                </label>
              );
            })}
          </div>
        </section>

        <footer className="global-exportHistorial-footer">
          <button
            type="button"
            className="global-exportHistorial-action global-exportHistorial-action--secondary"
            onClick={onClose}
            disabled={loading || exportando}
          >
            {cancelLabel}
          </button>

          <button
            type="submit"
            className="global-exportHistorial-action global-exportHistorial-action--primary"
            disabled={submitDisabled}
          >
            <FontAwesomeIcon icon={exportando ? faSpinner : opcionFormato.icon} spin={exportando} />
            {exportando ? loadingLabel : confirmLabel}
          </button>
        </footer>
      </form>
    </div>
  ), portalTarget);
};

export default ModalExportarGlobal;
