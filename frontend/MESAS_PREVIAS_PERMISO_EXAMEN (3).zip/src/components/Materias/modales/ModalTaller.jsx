// src/components/Materias/modales/ModalTaller.jsx
import React, { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBook,
  faCheck,
  faCheckCircle,
  faFlask,
  faMagnifyingGlass,
  faSave,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import "../../Global/Global_css/Global_Modals.css";
import "./ModalMaterias.css";
import "./ModalTaller.css";

const TAB_DIVISIONES = "divisiones";
const TAB_CATEDRAS = "catedras";
const aMayusculas = (valor) => String(valor ?? "").toUpperCase();

const normalizar = (texto) =>
  String(texto || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

const esCursoEgresado = (curso) => {
  const nombre = normalizar(curso?.nombre_curso || curso?.curso || "");
  return nombre.includes("egresado");
};

const extraerIdsCatedras = (item) => {
  if (!item?.ids_catedras) return [];

  return String(item.ids_catedras)
    .split(",")
    .map((id) => Number(String(id).trim()))
    .filter(Boolean);
};

const extraerDivisionesIniciales = (item) => {
  if (item?.ids_divisiones) {
    const ids = String(item.ids_divisiones)
      .split(",")
      .map((id) => Number(String(id).trim()))
      .filter(Boolean);

    if (ids.length > 0) return ids;
  }

  const idDivision = Number(item?.id_division || 0);
  return idDivision > 0 ? [idDivision] : [];
};

const ModalTaller = ({
  item,
  cursos = [],
  divisiones = [],
  areas = [],
  onObtenerMateriasPorCurso,
  onObtenerCatedrasTaller,
  onClose,
  onSave,
  onToast,
}) => {
  const [taller, setTaller] = useState(aMayusculas(item?.taller || ""));
  const [idCurso, setIdCurso] = useState(item?.id_curso || "");
  const [idsDivisiones, setIdsDivisiones] = useState(() =>
    extraerDivisionesIniciales(item)
  );
  const [activo, setActivo] = useState(item ? Number(item.activo) === 1 : true);
  const [idArea, setIdArea] = useState("");
  const [busqueda, setBusqueda] = useState("");
  const [seleccionadas, setSeleccionadas] = useState(() =>
    extraerIdsCatedras(item)
  );
  const [catedrasCurso, setCatedrasCurso] = useState([]);
  const [idsDivisionesConCatedras, setIdsDivisionesConCatedras] = useState([]);
  const [cargandoDivisionesCurso, setCargandoDivisionesCurso] = useState(false);
  const [cargandoCatedras, setCargandoCatedras] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [pestaniaActiva, setPestaniaActiva] = useState(TAB_DIVISIONES);

  useEffect(() => {
    const overflowAnterior = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (event) => {
      if (event.key !== "Escape") return;

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();

      if (!guardando) onClose?.();
    };

    document.addEventListener("keydown", handleKeyDown, true);

    return () => {
      document.body.style.overflow = overflowAnterior;
      document.removeEventListener("keydown", handleKeyDown, true);
    };
  }, [guardando, onClose]);

  useEffect(() => {
    setTaller(aMayusculas(item?.taller || ""));
    setIdCurso(item?.id_curso || "");
    setIdsDivisiones(extraerDivisionesIniciales(item));
    setActivo(item ? Number(item.activo) === 1 : true);
    setSeleccionadas(extraerIdsCatedras(item));
    setIdsDivisionesConCatedras([]);
    setCargandoDivisionesCurso(false);
    setIdArea("");
    setBusqueda("");
    setPestaniaActiva(TAB_DIVISIONES);
  }, [item]);

  useEffect(() => {
    let cancelado = false;

    const cargarCatedras = async () => {
      const id = Number(idCurso || 0);
      const divisionesSeleccionadas = idsDivisiones
        .map(Number)
        .filter((x) => x > 0);

      if (id <= 0 || divisionesSeleccionadas.length === 0) {
        setCatedrasCurso([]);
        return;
      }

      setCargandoCatedras(true);

      try {
        let lista = [];

        if (typeof onObtenerCatedrasTaller === "function") {
          lista = await onObtenerCatedrasTaller(id, divisionesSeleccionadas);
        } else if (typeof onObtenerMateriasPorCurso === "function") {
          const resultados = await Promise.all(
            divisionesSeleccionadas.map((idDivision) =>
              onObtenerMateriasPorCurso(id, { idDivision })
            )
          );
          lista = resultados.flat();
        } else {
          onToast?.("error", "No está configurada la carga de cátedras del taller.");
        }

        if (!cancelado) {
          setCatedrasCurso(Array.isArray(lista) ? lista : []);
        }
      } catch (error) {
        console.error(error);

        if (!cancelado) {
          setCatedrasCurso([]);
          onToast?.("error", "No se pudieron cargar las cátedras de ese curso y división.");
        }
      } finally {
        if (!cancelado) setCargandoCatedras(false);
      }
    };

    cargarCatedras();

    return () => {
      cancelado = true;
    };
  }, [
    idCurso,
    idsDivisiones,
    onObtenerCatedrasTaller,
    onObtenerMateriasPorCurso,
    onToast,
  ]);

  const cursosActivos = useMemo(() => {
    return cursos.filter((c) => Number(c.activo ?? 1) === 1 && !esCursoEgresado(c));
  }, [cursos]);

  const divisionesActivas = useMemo(() => {
    return divisiones.filter((d) => Number(d.activo ?? 1) === 1);
  }, [divisiones]);

  useEffect(() => {
    let cancelado = false;

    const cargarDivisionesDisponibles = async () => {
      const id = Number(idCurso || 0);
      const idsTodasDivisiones = divisionesActivas
        .map((d) => Number(d.id_division))
        .filter((x) => x > 0);

      setIdsDivisionesConCatedras([]);

      if (id <= 0 || idsTodasDivisiones.length === 0) {
        setCargandoDivisionesCurso(false);
        return;
      }

      setCargandoDivisionesCurso(true);

      try {
        let lista = [];

        if (typeof onObtenerCatedrasTaller === "function") {
          lista = await onObtenerCatedrasTaller(id, idsTodasDivisiones);
        } else if (typeof onObtenerMateriasPorCurso === "function") {
          const resultados = await Promise.all(
            idsTodasDivisiones.map((idDivision) =>
              onObtenerMateriasPorCurso(id, { idDivision })
            )
          );
          lista = resultados.flat();
        }

        if (!cancelado) {
          const ids = Array.from(
            new Set(
              (Array.isArray(lista) ? lista : [])
                .map((cat) => Number(cat.id_division || 0))
                .filter((x) => x > 0)
            )
          );

          setIdsDivisionesConCatedras(ids);
        }
      } catch (error) {
        console.error(error);

        if (!cancelado) {
          setIdsDivisionesConCatedras([]);
          onToast?.("error", "No se pudieron cargar las divisiones disponibles de ese curso.");
        }
      } finally {
        if (!cancelado) setCargandoDivisionesCurso(false);
      }
    };

    cargarDivisionesDisponibles();

    return () => {
      cancelado = true;
    };
  }, [idCurso, divisionesActivas, onObtenerCatedrasTaller, onObtenerMateriasPorCurso, onToast]);

  const divisionesDisponiblesCurso = useMemo(() => {
    if (!idCurso) return [];

    const idsDisponibles = new Set(idsDivisionesConCatedras.map(Number));
    const idsSeleccionadas = new Set(idsDivisiones.map(Number));

    return divisionesActivas.filter((d) => {
      const id = Number(d.id_division);
      return idsDisponibles.has(id) || idsSeleccionadas.has(id);
    });
  }, [idCurso, divisionesActivas, idsDivisionesConCatedras, idsDivisiones]);

  const catedrasNormalizadas = useMemo(() => {
    return catedrasCurso
      .map((m) => ({
        ...m,
        id_catedra_num: Number(m.id_catedra || 0),
        id_materia_num: Number(m.id_materia || 0),
        id_division_num: Number(m.id_division || 0),
        activo_num: Number(m.activo ?? 1),
        ids_area_array: String(m.ids_areas || m.id_area || "")
          .split(",")
          .map((x) => Number(String(x).trim()))
          .filter(Boolean),
      }))
      .filter((m) => Number(m.id_catedra_num) > 0);
  }, [catedrasCurso]);

  const catedrasFiltradas = useMemo(() => {
    const q = normalizar(busqueda);
    const area = Number(idArea || 0);

    return catedrasNormalizadas.filter((m) => {
      if (m.activo_num !== 1) return false;
      if (area > 0 && !m.ids_area_array.includes(area)) return false;
      if (!q) return true;

      return (
        normalizar(m.materia).includes(q) ||
        normalizar(m.areas).includes(q) ||
        normalizar(m.division).includes(q) ||
        normalizar(m.docente).includes(q) ||
        normalizar(m.cargo_docente || m.cargo).includes(q)
      );
    });
  }, [catedrasNormalizadas, idArea, busqueda]);

  const catedrasAgrupadas = useMemo(() => {
    const grupos = new Map();

    catedrasFiltradas.forEach((cat) => {
      const idDivision = Number(cat.id_division || 0);
      const nombreDivision = cat.division || `División ${idDivision}`;
      const clave = `${idDivision}-${nombreDivision}`;

      if (!grupos.has(clave)) {
        grupos.set(clave, {
          id_division: idDivision,
          division: nombreDivision,
          catedras: [],
        });
      }

      grupos.get(clave).catedras.push(cat);
    });

    return Array.from(grupos.values()).sort(
      (a, b) => Number(a.id_division) - Number(b.id_division)
    );
  }, [catedrasFiltradas]);

  const divisionesTexto = useMemo(() => {
    if (idsDivisiones.length === 0) return "Seleccioná una o varias divisiones.";

    const nombres = idsDivisiones
      .map(
        (id) =>
          divisionesDisponiblesCurso.find(
            (d) => Number(d.id_division) === Number(id)
          )?.nombre_division
      )
      .filter(Boolean);

    return nombres.length > 0
      ? nombres.join(", ")
      : `${idsDivisiones.length} división/es`;
  }, [idsDivisiones, divisionesDisponiblesCurso]);

  const cursoSeleccionadoTexto = useMemo(() => {
    if (!idCurso) return "Sin curso";

    return (
      cursosActivos.find((c) => Number(c.id_curso) === Number(idCurso))
        ?.nombre_curso || "Curso seleccionado"
    );
  }, [idCurso, cursosActivos]);

  const catedrasSeleccionadasTexto = useMemo(() => {
    if (!idCurso) return "Primero seleccioná el curso/año del taller.";
    if (idsDivisiones.length === 0) return "Ahora seleccioná una o varias divisiones.";
    if (cargandoCatedras) return "Cargando cátedras reales...";
    if (seleccionadas.length === 0) return "No seleccionaste cátedras todavía.";

    return `${seleccionadas.length} cátedra${
      seleccionadas.length === 1 ? "" : "s"
    } seleccionada${seleccionadas.length === 1 ? "" : "s"}.`;
  }, [idCurso, idsDivisiones.length, cargandoCatedras, seleccionadas.length]);

  const cambiarCurso = (valor) => {
    setIdCurso(valor);
    setIdsDivisiones([]);
    setIdsDivisionesConCatedras([]);
    setSeleccionadas([]);
    setIdArea("");
    setBusqueda("");
    setPestaniaActiva(TAB_DIVISIONES);
  };

  const toggleDivision = (idDivision) => {
    const id = Number(idDivision);
    if (!id) return;

    setIdsDivisiones((prev) => {
      const actual = prev.map(Number);
      if (actual.includes(id)) return actual.filter((x) => x !== id);
      return [...actual, id];
    });

    setSeleccionadas([]);
    setIdArea("");
    setBusqueda("");
  };

  const seleccionarTodasDivisiones = () => {
    setIdsDivisiones(
      divisionesDisponiblesCurso.map((d) => Number(d.id_division)).filter(Boolean)
    );
    setSeleccionadas([]);
    setIdArea("");
    setBusqueda("");
  };

  const limpiarDivisiones = () => {
    setIdsDivisiones([]);
    setSeleccionadas([]);
    setIdArea("");
    setBusqueda("");
  };

  const toggleCatedra = (idCatedra) => {
    const id = Number(idCatedra);

    setSeleccionadas((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const seleccionarVisibles = () => {
    const visibles = catedrasFiltradas.map((m) => Number(m.id_catedra));

    setSeleccionadas((prev) => {
      const set = new Set(prev.map(Number));
      visibles.forEach((id) => set.add(id));
      return Array.from(set);
    });
  };

  const limpiarVisibles = () => {
    const visibles = new Set(catedrasFiltradas.map((m) => Number(m.id_catedra)));
    setSeleccionadas((prev) => prev.filter((id) => !visibles.has(Number(id))));
  };

  const limpiarTodo = () => {
    setSeleccionadas([]);
  };

  const guardar = async (e) => {
    e.preventDefault();

    const nombre = aMayusculas(taller).trim();

    if (!nombre) {
      onToast?.("error", "El nombre del taller es obligatorio.");
      return;
    }

    if (!idCurso) {
      onToast?.("error", "Tenés que seleccionar el curso/año al que pertenece el taller.");
      return;
    }

    if (idsDivisiones.length === 0) {
      setPestaniaActiva(TAB_DIVISIONES);
      onToast?.("error", "Tenés que seleccionar al menos una división.");
      return;
    }

    if (seleccionadas.length === 0) {
      setPestaniaActiva(TAB_CATEDRAS);
      onToast?.("error", "Tenés que seleccionar las cátedras específicas de ese taller.");
      return;
    }

    setGuardando(true);

    onSave({
      id_taller: item?.id_taller || null,
      id_curso: Number(idCurso),
      divisiones: idsDivisiones.map(Number),
      id_division:
        idsDivisiones.length === 1 ? Number(idsDivisiones[0]) : undefined,
      taller: nombre,
      activo: activo ? 1 : 0,
      catedras: seleccionadas.map(Number),
    });
  };

  return createPortal(
    <div
      className="gm-modalOverlay materias-modal-overlay"
      role="presentation"
      onMouseDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <form
        className="gm-modal gm-modal--materias-lg materias-modal materias-modal--taller large"
        onSubmit={guardar}
        role="dialog"
        aria-modal="true"
        aria-labelledby="taller-modal-title"
        onMouseDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="gm-modal__header materias-modal-header">
          <div className="gm-modal__headIcon materias-modal-icon" aria-hidden="true">
            <FontAwesomeIcon icon={faFlask} />
          </div>

          <div className="gm-modal__headText">
            <h2 id="taller-modal-title">{item ? "Editar taller" : "Nuevo taller"}</h2>
            <p>
              Gestioná curso, divisiones y cátedras reales desde una interfaz ordenada.
            </p>
          </div>

          <button
            type="button"
            className="gm-modal__close modal-close"
            onClick={onClose}
            aria-label="Cerrar modal"
          >
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>

        <div className="materias-modal-scroll taller-modal-scroll">
          <div className="materias-taller-layout">
            <div className="form-grid three taller-main-grid">
              <label className="form-label">
                Nombre del taller
                <input
                  value={taller}
                  onChange={(e) => setTaller(aMayusculas(e.target.value))}
                  placeholder="EJ: TALLER DIBUJO TÉCNICO"
                  autoFocus
                />
              </label>

              <label className="form-label">
                Curso / año del taller
                <select value={idCurso} onChange={(e) => cambiarCurso(e.target.value)}>
                  <option value="">Seleccionar curso</option>
                  {cursosActivos.map((c) => (
                    <option key={c.id_curso} value={c.id_curso}>
                      {aMayusculas(c.nombre_curso)}
                    </option>
                  ))}
                </select>
              </label>

              <div className="gm-field gm-field--status taller-status-field">
                <div className="gm-statusToggle" role="group" aria-label="Estado del taller">
                  <button
                    type="button"
                    className={`gm-statusToggle__btn ${activo ? "is-active" : ""}`}
                    onClick={() => setActivo(true)}
                  >
                    <FontAwesomeIcon icon={faCheckCircle} />
                    Activo
                  </button>

                  <button
                    type="button"
                    className={`gm-statusToggle__btn gm-statusToggle__btn--danger ${!activo ? "is-active" : ""}`}
                    onClick={() => setActivo(false)}
                  >
                    Inactivo
                  </button>
                </div>
              </div>
            </div>


            <div className="taller-summary-strip" aria-label="Resumen del taller">
              <div className="taller-summary-card">
                <span>Curso</span>
                <strong>{cursoSeleccionadoTexto}</strong>
              </div>

              <div className="taller-summary-card">
                <span>Divisiones</span>
                <strong>{idsDivisiones.length}</strong>
              </div>

              <div className="taller-summary-card">
                <span>Cátedras</span>
                <strong>{seleccionadas.length}</strong>
              </div>
            </div>

            <div
              className="gm-tabs gm-tabs--google materias-modal-tabs materias-taller-tabs"
              role="tablist"
              aria-label="Secciones del taller"
            >
              <button
                type="button"
                role="tab"
                id="taller-tab-divisiones"
                aria-controls="taller-panel-divisiones"
                aria-selected={pestaniaActiva === TAB_DIVISIONES}
                className={`gm-tab${pestaniaActiva === TAB_DIVISIONES ? " is-active" : ""}`}
                onClick={() => setPestaniaActiva(TAB_DIVISIONES)}
              >
                <FontAwesomeIcon icon={faFlask} />
                <span>Divisiones</span>
                {idsDivisiones.length > 0 && (
                  <span className="gm-tab__badge">{idsDivisiones.length}</span>
                )}
              </button>

              <button
                type="button"
                role="tab"
                id="taller-tab-catedras"
                aria-controls="taller-panel-catedras"
                aria-selected={pestaniaActiva === TAB_CATEDRAS}
                className={`gm-tab${pestaniaActiva === TAB_CATEDRAS ? " is-active" : ""}`}
                onClick={() => setPestaniaActiva(TAB_CATEDRAS)}
              >
                <FontAwesomeIcon icon={faBook} />
                <span>Cátedras</span>
                {seleccionadas.length > 0 && (
                  <span className="gm-tab__badge">{seleccionadas.length}</span>
                )}
              </button>
            </div>

            {pestaniaActiva === TAB_DIVISIONES && (
              <div
                className="taller-box materias-taller-panel"
                id="taller-panel-divisiones"
                role="tabpanel"
                aria-labelledby="taller-tab-divisiones"
              >
                <div className="taller-box-title-row">
                  <div>
                    <h4>Divisiones del taller</h4>
                    <p className="muted">{divisionesTexto}</p>
                  </div>

                  <div className="taller-bulk-actions compact-actions">
                    <button
                      type="button"
                      className="gm-btn gm-btn--ghost"
                      onClick={seleccionarTodasDivisiones}
                      disabled={!idCurso || cargandoDivisionesCurso || divisionesDisponiblesCurso.length === 0}
                    >
                      Todas
                    </button>

                    <button
                      type="button"
                      className="gm-btn gm-btn--ghost"
                      onClick={limpiarDivisiones}
                      disabled={idsDivisiones.length === 0}
                    >
                      Limpiar
                    </button>
                  </div>
                </div>

                {!idCurso ? (
                  <div className="muted asignar-empty">
                    Seleccioná el curso para habilitar las divisiones.
                  </div>
                ) : cargandoDivisionesCurso ? (
                  <div className="muted asignar-empty">
                    Cargando divisiones disponibles para ese curso...
                  </div>
                ) : divisionesDisponiblesCurso.length === 0 ? (
                  <div className="muted asignar-empty">
                    No hay divisiones con cátedras cargadas para ese curso.
                  </div>
                ) : (
                  <div className="materias-check-grid divisiones-check-grid">
                    {divisionesDisponiblesCurso.map((d) => {
                      const id = Number(d.id_division);
                      const checked = idsDivisiones.map(Number).includes(id);

                      return (
                        <label
                          key={d.id_division}
                          className={`materia-check ${checked ? "checked" : ""}`}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => toggleDivision(id)}
                          />
                          <span>
                            <strong>{aMayusculas(d.nombre_division)}</strong>
                          </span>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {pestaniaActiva === TAB_CATEDRAS && (
              <div
                className="taller-box materias-taller-panel"
                id="taller-panel-catedras"
                role="tabpanel"
                aria-labelledby="taller-tab-catedras"
              >
                <div className="taller-box-title-row">
                  <div>
                    <h4>Cátedras del taller</h4>
                    <p className="muted">{catedrasSeleccionadasTexto}</p>
                  </div>
                </div>


                <div className="taller-toolbar">
                  <label className="form-label mini">
                    Filtrar por área
                    <select
                      value={idArea}
                      onChange={(e) => setIdArea(e.target.value)}
                      disabled={!idCurso || idsDivisiones.length === 0 || cargandoCatedras}
                    >
                      <option value="">Todas las áreas</option>
                      {areas.map((a) => (
                        <option key={a.id_area} value={a.id_area}>
                          {aMayusculas(a.area)}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="form-label mini taller-search-label">
                    Buscar cátedra
                    <span className="taller-search-wrap">
                      <input
                        value={busqueda}
                        onChange={(e) => setBusqueda(aMayusculas(e.target.value))}
                        placeholder={
                          idCurso && idsDivisiones.length > 0
                            ? "Buscar por materia, área, división o docente"
                            : "Primero seleccioná curso y división"
                        }
                        disabled={!idCurso || idsDivisiones.length === 0 || cargandoCatedras}
                      />
                      <FontAwesomeIcon icon={faMagnifyingGlass} />
                    </span>
                  </label>
                </div>

                <div className="taller-bulk-actions">
                  <button
                    type="button"
                    className="gm-btn gm-btn--ghost"
                    onClick={seleccionarVisibles}
                    disabled={
                      !idCurso ||
                      idsDivisiones.length === 0 ||
                      cargandoCatedras ||
                      catedrasFiltradas.length === 0
                    }
                  >
                    <FontAwesomeIcon icon={faCheck} />
                    Seleccionar visibles
                  </button>

                  <button
                    type="button"
                    className="gm-btn gm-btn--ghost"
                    onClick={limpiarVisibles}
                    disabled={
                      !idCurso ||
                      idsDivisiones.length === 0 ||
                      cargandoCatedras ||
                      catedrasFiltradas.length === 0
                    }
                  >
                    Limpiar visibles
                  </button>

                  <button
                    type="button"
                    className="gm-btn gm-btn--ghost"
                    onClick={limpiarTodo}
                    disabled={seleccionadas.length === 0}
                  >
                    Limpiar todo
                  </button>
                </div>

                {!idCurso ? (
                  <div className="muted asignar-empty">
                    Seleccioná el curso del taller para cargar las cátedras.
                  </div>
                ) : idsDivisiones.length === 0 ? (
                  <div className="muted asignar-empty">
                    Seleccioná una o varias divisiones. Después podés seleccionar
                    las cátedras reales de cada división.
                  </div>
                ) : cargandoCatedras ? (
                  <div className="muted asignar-empty">
                    Cargando cátedras del curso y divisiones seleccionadas...
                  </div>
                ) : catedrasFiltradas.length === 0 ? (
                  <div className="muted asignar-empty">
                    No hay cátedras para mostrar con ese curso/división/filtro.
                  </div>
                ) : (
                  <div className="taller-catedras-groups">
                    {catedrasAgrupadas.map((grupo) => (
                      <div
                        key={grupo.id_division || grupo.division}
                        className="taller-catedras-group"
                      >
                        <div className="taller-group-title">
                          División {aMayusculas(grupo.division)}
                        </div>

                        <div className="materias-check-grid">
                          {grupo.catedras.map((m) => {
                            const id = Number(m.id_catedra);
                            const checked = seleccionadas.includes(id);

                            return (
                              <label
                                key={m.id_catedra}
                                className={`materia-check ${checked ? "checked" : ""}`}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => toggleCatedra(id)}
                                />

                                <span>
                                  <strong>{aMayusculas(m.materia)}</strong>
                                  {m.areas ? <small>{aMayusculas(m.areas)}</small> : null}
                                  {m.docente ? (
                                    <small>
                                      Docente: {aMayusculas(m.docente)}
                                      {m.cargo_docente || m.cargo
                                        ? ` · Cargo: ${aMayusculas(m.cargo_docente || m.cargo)}`
                                        : ''}
                                    </small>
                                  ) : null}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="gm-modal__actions modal-actions materias-editor-actions">
          <button type="button" className="gm-btn gm-btn--ghost" onClick={onClose}>
            Cancelar
          </button>

          <button
            type="submit"
            className="gm-btn gm-btn--primary"
            disabled={guardando || cargandoCatedras}
          >
            <FontAwesomeIcon icon={faSave} />
            {guardando ? "Guardando..." : "Guardar taller"}
          </button>
        </div>
      </form>
    </div>,
    document.body
  );
};

export default ModalTaller;
