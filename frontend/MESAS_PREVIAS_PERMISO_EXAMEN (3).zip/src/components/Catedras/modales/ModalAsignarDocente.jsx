import React, { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faChalkboardTeacher,
  faCircleInfo,
  faPlus,
  faSave,
  faSearch,
  faTimes,
  faTrash,
  faUserCheck,
  faUserSlash,
  faUsers,
} from '@fortawesome/free-solid-svg-icons';
import '../../Global/Global_css/Global_Modals.css';
import ModalContenidoGlobal from '../../Global/Modales/ModalContenidoGlobal.jsx';
import './ModalCatedras.css';

function normalizar(texto) {
  return String(texto || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

function valorObjeto(objeto, claves = []) {
  if (!objeto || typeof objeto !== 'object') return '';

  for (const clave of claves) {
    const valor = objeto[clave];
    if (valor !== null && valor !== undefined && String(valor).trim() !== '') {
      return String(valor).trim();
    }
  }

  return '';
}

function valorDocente(docente, claves = []) {
  return valorObjeto(docente, claves);
}

function obtenerIdDocente(docente) {
  return valorDocente(docente, ['id_docente', 'idDocente', 'id', 'value']);
}

function obtenerNombreDocente(docente) {
  const nombreDirecto = valorDocente(docente, [
    'docente',
    'nombre_docente',
    'nombreDocente',
    'nombre_completo',
    'nombreCompleto',
    'text',
    'label',
  ]);

  if (nombreDirecto) return nombreDirecto;

  const apellido = valorDocente(docente, ['apellido', 'apellidos', 'apellido_docente', 'apellidos_docente']);
  const nombre = valorDocente(docente, ['nombre', 'nombres', 'nombre_persona', 'nombres_docente']);
  const compuesto = `${apellido} ${nombre}`.trim();

  return compuesto || 'Docente sin nombre';
}

function obtenerDocumentoDocente(docente) {
  return valorDocente(docente, ['dni', 'documento', 'cuil', 'cuit', 'legajo']);
}

function obtenerIdCargo(cargo) {
  return valorObjeto(cargo, ['id_cargo', 'idCargo', 'id', 'value']);
}

function obtenerNombreCargo(cargo) {
  return valorObjeto(cargo, ['cargo', 'nombre_cargo', 'nombreCargo', 'text', 'label']) || 'Cargo sin nombre';
}

function docenteEstaActivo(docente) {
  const clavesEstado = ['activo', 'activa', 'estado', 'estado_docente', 'estadoDocente', 'habilitado'];
  const claveExistente = clavesEstado.find((clave) => Object.prototype.hasOwnProperty.call(docente || {}, clave));

  if (!claveExistente) return true;

  const valor = docente[claveExistente];

  if (typeof valor === 'boolean') return valor;
  if (typeof valor === 'number') return valor === 1;

  const estado = normalizar(valor);
  if (!estado) return true;

  return ![
    '0',
    'false',
    'no',
    'inactivo',
    'inactiva',
    'baja',
    'dado de baja',
    'dada de baja',
    'deshabilitado',
    'deshabilitada',
    'eliminado',
    'eliminada',
  ].includes(estado);
}

function textoBusquedaDocente(docente) {
  return normalizar([
    obtenerNombreDocente(docente),
    obtenerDocumentoDocente(docente),
    valorDocente(docente, ['email', 'correo', 'telefono', 'teléfono']),
  ].filter(Boolean).join(' '));
}

function nombreCargoEs(cargo, esperado) {
  return normalizar(obtenerNombreCargo(cargo)) === normalizar(esperado);
}

function esDocenteSinCargoCubierto(nombreDocente) {
  const nombre = normalizar(nombreDocente);
  return nombre === 'materia sin cargo cubierto' || nombre === 'sin cargo cubierto';
}

function normalizarAsignacionesIniciales(item) {
  const desdeBackend = Array.isArray(item?.docentes_asignados) ? item.docentes_asignados : [];

  if (desdeBackend.length > 0) {
    return desdeBackend
      .map((asignacion) => ({
        id_docente: Number(asignacion.id_docente || 0),
        docente: String(asignacion.docente || '').trim(),
        id_cargo: Number(asignacion.id_cargo || 0),
        cargo: String(asignacion.cargo || asignacion.cargo_docente || '').trim(),
        llamado_mesa: Boolean(asignacion.llamado_mesa || asignacion.es_llamado || asignacion.llamado || asignacion.se_llama),
      }))
      .filter((asignacion) => (
        asignacion.id_docente > 0
        && asignacion.id_cargo > 0
        && !esDocenteSinCargoCubierto(asignacion.docente)
      ));
  }

  const idDocente = Number(item?.id_docente || 0);
  const idCargo = Number(item?.id_cargo || 0);

  if (idDocente > 0 && idCargo > 0 && !esDocenteSinCargoCubierto(item?.docente)) {
    return [{
      id_docente: idDocente,
      docente: String(item?.docente || '').trim(),
      id_cargo: idCargo,
      cargo: String(item?.cargo_docente || item?.cargo || '').trim(),
      llamado_mesa: true,
    }];
  }

  return [];
}

function textoAsignacion(asignacion) {
  const docente = String(asignacion?.docente || '').trim() || `Docente #${asignacion?.id_docente || ''}`.trim();
  const cargo = String(asignacion?.cargo || '').trim();
  return cargo ? `${docente} · ${cargo}` : docente;
}

function obtenerDocenteLlamado(asignaciones, idDocenteLlamado = '') {
  if (!Array.isArray(asignaciones) || asignaciones.length === 0) return null;

  const idLlamado = Number(idDocenteLlamado || 0);
  if (idLlamado > 0) {
    const asignacionElegida = asignaciones.find((asignacion) => Number(asignacion.id_docente) === idLlamado);
    if (asignacionElegida) return asignacionElegida;
  }

  // Si todavía no se eligió manualmente, se llama al último agregado respetando la prioridad habitual.
  const ordenInverso = [...asignaciones].reverse();
  const suplente = ordenInverso.find((asignacion) => Number(asignacion.id_cargo) === 2 || normalizar(asignacion.cargo) === 'suplente');
  if (suplente) return suplente;

  const titular = ordenInverso.find((asignacion) => Number(asignacion.id_cargo) === 1 || normalizar(asignacion.cargo) === 'titular');
  if (titular) return titular;

  return ordenInverso[0] || null;
}

function obtenerIdDocenteLlamadoInicial(asignaciones) {
  const marcado = Array.isArray(asignaciones)
    ? asignaciones.find((asignacion) => Boolean(asignacion.llamado_mesa))
    : null;

  if (marcado && Number(marcado.id_docente || 0) > 0) {
    return String(marcado.id_docente);
  }

  const llamado = obtenerDocenteLlamado(asignaciones);
  return llamado && Number(llamado.id_docente || 0) > 0 ? String(llamado.id_docente) : '';
}

function prioridadCargoAsignacion(asignacion) {
  const cargo = normalizar(asignacion?.cargo);
  if (Number(asignacion?.id_cargo) === 2 || cargo === 'suplente') return 0;
  if (Number(asignacion?.id_cargo) === 1 || cargo === 'titular') return 1;
  return 2;
}

function ordenarAsignacionesParaGuardar(asignaciones, idDocenteLlamado) {
  const idLlamado = Number(idDocenteLlamado || 0);
  return [...(Array.isArray(asignaciones) ? asignaciones : [])].sort((a, b) => {
    const prioridadA = prioridadCargoAsignacion(a);
    const prioridadB = prioridadCargoAsignacion(b);

    if (prioridadA === prioridadB) {
      if (Number(a.id_docente) === idLlamado) return 1;
      if (Number(b.id_docente) === idLlamado) return -1;
    }

    return 0;
  });
}

export default function ModalAsignarDocente({ item, docentes = [], cargos = [], onGuardar, onCerrar }) {
  const [asignaciones, setAsignaciones] = useState(() => normalizarAsignacionesIniciales(item));
  const [idDocenteLlamado, setIdDocenteLlamado] = useState(() => obtenerIdDocenteLlamadoInicial(normalizarAsignacionesIniciales(item)));
  const [idDocente, setIdDocente] = useState('');
  const [idCargo, setIdCargo] = useState('');
  const [idDocenteEditando, setIdDocenteEditando] = useState('');
  const [busqueda, setBusqueda] = useState('');
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState('');
  const [modalDetalleResumen, setModalDetalleResumen] = useState(null);

  useEffect(() => {
    const overflowAnterior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (event) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();
      if (modalDetalleResumen) {
        setModalDetalleResumen(null);
        return;
      }

      onCerrar?.();
    };

    document.addEventListener('keydown', handleKeyDown, true);

    return () => {
      document.body.style.overflow = overflowAnterior;
      document.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [onCerrar, modalDetalleResumen]);

  const listaDocentes = useMemo(() => (Array.isArray(docentes) ? docentes : []), [docentes]);
  const listaCargos = useMemo(() => (Array.isArray(cargos) ? cargos : []), [cargos]);

  const docentesActivos = useMemo(() => (
    listaDocentes.filter((docente) => docenteEstaActivo(docente) && !esDocenteSinCargoCubierto(obtenerNombreDocente(docente)))
  ), [listaDocentes]);

  const cargosActivos = useMemo(() => (
    listaCargos.filter((cargo) => docenteEstaActivo(cargo))
  ), [listaCargos]);

  const docentesFiltrados = useMemo(() => {
    const q = normalizar(busqueda);
    if (!q) return docentesActivos;

    return docentesActivos.filter((docente) => textoBusquedaDocente(docente).includes(q));
  }, [docentesActivos, busqueda]);

  useEffect(() => {
    const q = normalizar(busqueda);
    if (!q) return;

    const primerDocente = docentesFiltrados[0];
    const primerId = primerDocente ? String(obtenerIdDocente(primerDocente)) : '';

    setIdDocente((actual) => (actual === primerId ? actual : primerId));
  }, [busqueda, docentesFiltrados]);

  useEffect(() => {
    if (idCargo || cargosActivos.length === 0) return;

    const cargoTitular = cargosActivos.find((cargo) => nombreCargoEs(cargo, 'TITULAR'));
    const primerCargo = cargoTitular || cargosActivos[0];
    const primerIdCargo = primerCargo ? String(obtenerIdCargo(primerCargo)) : '';

    if (primerIdCargo) setIdCargo(primerIdCargo);
  }, [idCargo, cargosActivos]);

  const docenteSeleccionado = useMemo(() => {
    if (!idDocente) return null;
    return listaDocentes.find((docente) => String(obtenerIdDocente(docente)) === String(idDocente)) || null;
  }, [listaDocentes, idDocente]);

  const cargoSeleccionado = useMemo(() => {
    if (!idCargo) return null;
    return listaCargos.find((cargo) => String(obtenerIdCargo(cargo)) === String(idCargo)) || null;
  }, [listaCargos, idCargo]);

  const docentesParaSelect = useMemo(() => {
    if (!docenteSeleccionado) return docentesFiltrados;

    const seleccionadoEstaEnFiltro = docentesFiltrados.some(
      (docente) => String(obtenerIdDocente(docente)) === String(idDocente)
    );

    return seleccionadoEstaEnFiltro ? docentesFiltrados : [docenteSeleccionado, ...docentesFiltrados];
  }, [docenteSeleccionado, docentesFiltrados, idDocente]);

  const docenteLlamado = useMemo(() => obtenerDocenteLlamado(asignaciones, idDocenteLlamado), [asignaciones, idDocenteLlamado]);
  const estaEditandoAsignacion = Number(idDocenteEditando || 0) > 0;

  useEffect(() => {
    if (asignaciones.length === 0) {
      if (idDocenteLlamado) setIdDocenteLlamado('');
      return;
    }

    const existeLlamado = asignaciones.some((asignacion) => Number(asignacion.id_docente) === Number(idDocenteLlamado || 0));
    if (!existeLlamado) {
      setIdDocenteLlamado(obtenerIdDocenteLlamadoInicial(asignaciones));
    }
  }, [asignaciones, idDocenteLlamado]);

  function limpiarEdicion() {
    setIdDocente('');
    setIdDocenteEditando('');
    setBusqueda('');
  }

  function seleccionarAsignacionParaEditar(asignacion) {
    if (guardando) return;

    setError('');
    setIdDocente(String(asignacion.id_docente || ''));
    setIdCargo(String(asignacion.id_cargo || ''));
    setIdDocenteEditando(String(asignacion.id_docente || ''));
    setBusqueda('');
  }

  function agregarAsignacion() {
    setError('');

    const idDocenteNumero = idDocente ? Number(idDocente) : 0;
    const idCargoNumero = idCargo ? Number(idCargo) : 0;
    const idDocenteEditandoNumero = idDocenteEditando ? Number(idDocenteEditando) : 0;
    const estaEditando = idDocenteEditandoNumero > 0;

    if (idDocenteNumero <= 0) {
      setError('Seleccioná un docente para agregarlo a la cátedra.');
      return;
    }

    if (idCargoNumero <= 0) {
      setError('Seleccioná el cargo que tendrá ese docente en la cátedra.');
      return;
    }

    if (asignaciones.some((asignacion) => (
      Number(asignacion.id_docente) === idDocenteNumero
      && Number(asignacion.id_docente) !== idDocenteEditandoNumero
    ))) {
      setError('Ese docente ya está asignado en esta cátedra.');
      return;
    }


    const nuevaAsignacion = {
      id_docente: idDocenteNumero,
      docente: docenteSeleccionado ? obtenerNombreDocente(docenteSeleccionado) : '',
      id_cargo: idCargoNumero,
      cargo: cargoSeleccionado ? obtenerNombreCargo(cargoSeleccionado) : '',
      llamado_mesa: Number(idDocenteLlamado || 0) === idDocenteNumero,
    };

    setAsignaciones((actual) => (estaEditando
      ? actual.map((asignacion) => (
        Number(asignacion.id_docente) === idDocenteEditandoNumero ? nuevaAsignacion : asignacion
      ))
      : [...actual, nuevaAsignacion]
    ));

    if (asignaciones.length === 0 || Number(idDocenteLlamado || 0) === idDocenteEditandoNumero) {
      setIdDocenteLlamado(String(idDocenteNumero));
    }

    limpiarEdicion();
  }

  function quitarAsignacion(idDocenteAsignacion) {
    setError('');
    setAsignaciones((actual) => actual.filter((asignacion) => Number(asignacion.id_docente) !== Number(idDocenteAsignacion)));

    if (Number(idDocenteLlamado || 0) === Number(idDocenteAsignacion)) {
      const restantes = asignaciones.filter((asignacion) => Number(asignacion.id_docente) !== Number(idDocenteAsignacion));
      setIdDocenteLlamado(obtenerIdDocenteLlamadoInicial(restantes));
    }

    if (Number(idDocenteEditando || 0) === Number(idDocenteAsignacion)) {
      limpiarEdicion();
    }
  }

  function quitarTodos() {
    setError('');
    setAsignaciones([]);
    setIdDocenteLlamado('');
    limpiarEdicion();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setGuardando(true);

    const payload = ordenarAsignacionesParaGuardar(asignaciones, idDocenteLlamado).map((asignacion) => ({
      id_docente: Number(asignacion.id_docente || 0),
      id_cargo: Number(asignacion.id_cargo || 0),
      llamado_mesa: Number(asignacion.id_docente || 0) === Number(idDocenteLlamado || 0),
    }));

    try {
      const resultado = await onGuardar(item.id_catedra, payload);
      if (!resultado?.ok) {
        setError(resultado?.mensaje || 'No se pudieron guardar los docentes de la cátedra.');
        setGuardando(false);
      }
    } catch (eGuardar) {
      setError(eGuardar?.message || 'No se pudieron guardar los docentes de la cátedra.');
      setGuardando(false);
    }
  }

  const docenteActual = asignaciones.length > 0
    ? asignaciones.map((asignacion) => textoAsignacion(asignacion)).join(', ')
    : 'Sin docentes asignados';
  const cantidadFiltrada = Array.isArray(docentesFiltrados) ? docentesFiltrados.length : 0;
  const cursoDivision = `${item?.nombre_curso || 'Curso'} ${item?.nombre_division || ''}`.trim();
  const textoLlamado = docenteLlamado
    ? `${textoAsignacion(docenteLlamado)}`
    : 'La cátedra quedará sin docente para llamar a mesa.';


  const detalleDocentesActuales = (
    <div className="catedras-modal-detalleResumen">
      <div className="catedras-modal-detalleResumen__head">
        <span>Cátedra</span>
        <strong>{item?.materia || '—'}</strong>
        <small>{cursoDivision}</small>
      </div>

      {asignaciones.length > 0 ? (
        <div className="catedras-modal-detalleResumen__list">
          {asignaciones.map((asignacion, index) => {
            const esLlamado = docenteLlamado && Number(docenteLlamado.id_docente) === Number(asignacion.id_docente);

            return (
              <div
                key={`detalle-${asignacion.id_docente}-${asignacion.id_cargo}-${index}`}
                className={`catedras-modal-detalleResumen__item ${esLlamado ? 'is-called' : ''}`}
              >
                <div className="catedras-modal-detalleResumen__number" aria-hidden="true">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <div className="catedras-modal-detalleResumen__text">
                  <span>Docente</span>
                  <strong>{asignacion.docente || `Docente #${asignacion.id_docente}`}</strong>
                  <small>{asignacion.cargo || 'Cargo sin nombre'}{esLlamado ? ' · se llamará a mesa' : ''}</small>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="catedras-modal-detalleResumen__empty">Todavía no hay docentes asignados a esta cátedra.</div>
      )}
    </div>
  );

  const detalleDocenteLlamado = (
    <div className="catedras-modal-detalleResumen">
      <div className="catedras-modal-detalleResumen__head">
        <span>Se llamará a mesa</span>
        <strong>{docenteLlamado ? textoAsignacion(docenteLlamado) : 'Sin docente definido'}</strong>
        <small>{item?.materia || '—'} · {cursoDivision}</small>
      </div>

      {docenteLlamado ? (
        <div className="catedras-modal-detalleResumen__list">
          <div className="catedras-modal-detalleResumen__item is-called">
            <div className="catedras-modal-detalleResumen__number" aria-hidden="true">01</div>
            <div className="catedras-modal-detalleResumen__text">
              <span>Docente seleccionado para mesa</span>
              <strong>{docenteLlamado.docente || `Docente #${docenteLlamado.id_docente}`}</strong>
              <small>{docenteLlamado.cargo || 'Cargo sin nombre'}</small>
            </div>
          </div>
        </div>
      ) : (
        <div className="catedras-modal-detalleResumen__empty">La cátedra quedará sin docente para llamar a mesa.</div>
      )}
    </div>
  );

  function abrirDetalleResumen(tipo) {
    if (tipo === 'docentes') {
      setModalDetalleResumen({
        title: 'Docentes actuales',
        subtitle: `${cursoDivision} — ${item?.materia || 'Materia sin nombre'}`,
        content: docenteActual,
        contentNode: detalleDocentesActuales,
      });
      return;
    }

    setModalDetalleResumen({
      title: 'Se llamará a mesa',
      subtitle: `${cursoDivision} — ${item?.materia || 'Materia sin nombre'}`,
      content: textoLlamado,
      contentNode: detalleDocenteLlamado,
    });
  }

  return createPortal(
    <div
      className="gm-modalOverlay catedras-modalOverlay"
      role="presentation"
      onMouseDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
      onClick={(e) => e.stopPropagation()}
    >
      <form
        className="gm-modal gm-modal--catedras catedras-docente-modal"
        onSubmit={handleSubmit}
        role="dialog"
        aria-modal="true"
        aria-labelledby="catedras-docente-modal-title"
        onMouseDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="gm-modal__header catedras-modal-header">
          <div className="gm-modal__headIcon catedras-modal-icon" aria-hidden="true">
            <FontAwesomeIcon icon={faChalkboardTeacher} />
          </div>

          <div className="gm-modal__headText catedras-modal-headText">
            <h2 id="catedras-docente-modal-title">Asignar docentes y cargos</h2>
            <p>{cursoDivision} — {item?.materia || 'Materia sin nombre'}</p>
          </div>

          <button
            type="button"
            className="gm-modal__close modal-close"
            onClick={onCerrar}
            aria-label="Cerrar modal"
            disabled={guardando}
          >
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>

        <div className="gm-modal__content catedras-modal-content">
          {error && (
            <div className="gm-alert gm-alert--error gm-alert--banner catedras-modal-alert">
              {error}
            </div>
          )}

          <div className="catedras-modal-summary" aria-label="Resumen de la cátedra">
            <div className="catedras-modal-summaryItem">
              <span>Cátedra</span>
              <strong title={item?.materia || ''}>{item?.materia || '—'}</strong>
            </div>

            <div className={`catedras-modal-summaryItem ${asignaciones.length > 0 ? 'is-active' : 'is-empty'}`}>
              <span className="catedras-modal-summaryItem__label">Docentes actuales</span>
              <div className="catedras-modal-summaryItem__valueWrap">
                <strong title={docenteActual}>{docenteActual}</strong>
                <button
                  type="button"
                  className="catedras-modal-summaryInfoBtn"
                  onClick={() => abrirDetalleResumen('docentes')}
                  aria-label="Ver docentes actuales completos"
                  title="Ver docentes actuales completos"
                >
                  <FontAwesomeIcon icon={faCircleInfo} />
                  <span></span>
                </button>
              </div>
            </div>

            <div className={`catedras-modal-summaryItem ${docenteLlamado ? 'is-active' : 'is-empty'}`}>
              <span className="catedras-modal-summaryItem__label">Se llamará a mesa</span>
              <div className="catedras-modal-summaryItem__valueWrap">
                <strong title={textoLlamado}>{textoLlamado}</strong>
                <button
                  type="button"
                  className="catedras-modal-summaryInfoBtn"
                  onClick={() => abrirDetalleResumen('mesa')}
                  aria-label="Ver docente llamado a mesa completo"
                  title="Ver docente llamado a mesa completo"
                >
                  <FontAwesomeIcon icon={faCircleInfo} />
                  <span></span>
                </button>
              </div>
            </div>
          </div>

          <section className="gm-panel catedras-modal-panel">
            <div className="gm-panel__head gm-panel__head--split">
              <div>
                <span className="gm-panel__eyebrow">{estaEditandoAsignacion ? 'Editando asignación' : 'Nueva asignación'}</span>
                <h3>
                  <FontAwesomeIcon icon={faUserCheck} />
                  {estaEditandoAsignacion ? 'Modificar docente y cargo' : 'Seleccionar docente y cargo'}
                </h3>
              </div>
              <span className="gm-panel__tag">{cantidadFiltrada} disponible{cantidadFiltrada === 1 ? '' : 's'}</span>
            </div>

            <div className="gm-panel__body catedras-modal-panelBody">
              <label className={`gm-field catedras-modal-searchField ${busqueda.trim() ? 'is-filled' : ''}`}>
                <FontAwesomeIcon icon={faSearch} className="catedras-modal-searchIcon" />
                <input
                  className="gm-input catedras-modal-searchInput"
                  type="text"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') e.preventDefault();
                  }}
                  placeholder=" "
                  autoFocus
                />
                <span className="gm-label">Buscar docente activo</span>
                {busqueda.trim() !== '' && (
                  <button
                    type="button"
                    className="catedras-modal-clearSearch"
                    onClick={() => setBusqueda('')}
                    aria-label="Limpiar búsqueda"
                  >
                    <FontAwesomeIcon icon={faTimes} />
                  </button>
                )}
              </label>

              <div className="catedras-modal-addGrid">
                <label className="gm-field catedras-modal-selectField">
                  <select
                    className="gm-input catedras-modal-select"
                    aria-label="Docente"
                    value={idDocente}
                    onChange={(e) => setIdDocente(e.target.value)}
                    disabled={guardando}
                  >
                    <option value="">Seleccionar docente</option>
                    {docentesParaSelect.length === 0 && busqueda.trim() !== '' ? (
                      <option value="" disabled>No se encontraron docentes activos</option>
                    ) : null}
                    {docentesParaSelect.map((docente) => {
                      const docenteId = obtenerIdDocente(docente);
                      const nombreDocente = obtenerNombreDocente(docente);

                      return (
                        <option key={docenteId || nombreDocente} value={docenteId}>
                          {nombreDocente}
                        </option>
                      );
                    })}
                  </select>
                  <span className="gm-label">Docente</span>
                </label>

                <label className="gm-field catedras-modal-selectField">
                  <select
                    className="gm-input catedras-modal-select"
                    aria-label="Cargo en esta cátedra"
                    value={idCargo}
                    onChange={(e) => setIdCargo(e.target.value)}
                    disabled={guardando}
                  >
                    <option value="">Seleccionar cargo</option>
                    {cargosActivos.map((cargo) => {
                      const cargoId = obtenerIdCargo(cargo);
                      const nombreCargo = obtenerNombreCargo(cargo);

                      return (
                        <option key={cargoId || nombreCargo} value={cargoId}>
                          {nombreCargo}
                        </option>
                      );
                    })}
                  </select>
                  <span className="gm-label">Cargo en esta cátedra</span>
                </label>

                <button
                  type="button"
                  className="gm-btn gm-btn--secondary catedras-modal-addBtn"
                  onClick={agregarAsignacion}
                  disabled={guardando}
                >
                  <FontAwesomeIcon icon={estaEditandoAsignacion ? faSave : faPlus} />
                  {estaEditandoAsignacion ? 'Actualizar' : 'Agregar'}
                </button>

                {estaEditandoAsignacion && (
                  <button
                    type="button"
                    className="gm-btn gm-btn--ghost catedras-modal-cancelEditBtn"
                    onClick={limpiarEdicion}
                    disabled={guardando}
                  >
                    <FontAwesomeIcon icon={faTimes} />
                    Cancelar edición
                  </button>
                )}
              </div>
            </div>
          </section>

          <section className="gm-panel catedras-modal-panel ">


            <div className="gm-panel__body catedras-modal-panelBody">
              {asignaciones.length > 0 ? (
                <div className="catedras-modal-asignacionesList">
                  {asignaciones.map((asignacion) => {
                    const esLlamado = docenteLlamado && Number(docenteLlamado.id_docente) === Number(asignacion.id_docente);
                    return (
                      <div
                        key={`${asignacion.id_docente}-${asignacion.id_cargo}`}
                        className={`catedras-modal-asignacionItem ${esLlamado ? 'is-called' : ''} ${Number(idDocenteEditando || 0) === Number(asignacion.id_docente) ? 'is-editing' : ''}`}
                        role="button"
                        tabIndex={guardando ? -1 : 0}
                        title="Click para editar esta asignación"
                        onClick={() => seleccionarAsignacionParaEditar(asignacion)}
                        onKeyDown={(e) => {
                          if (e.key !== 'Enter' && e.key !== ' ') return;
                          e.preventDefault();
                          seleccionarAsignacionParaEditar(asignacion);
                        }}
                      >
                        <div className="catedras-modal-asignacionIcon" aria-hidden="true">
                          <FontAwesomeIcon icon={esLlamado ? faUserCheck : faUsers} />
                        </div>
                        <div className="catedras-modal-asignacionText">
                          <strong title={asignacion.docente}>{asignacion.docente || `Docente #${asignacion.id_docente}`}</strong>
                          <span>{asignacion.cargo || 'Cargo sin nombre'}{esLlamado ? ' · llamado a mesa' : ''}</span>
                        </div>
                        <div className="catedras-modal-asignacionActions">
                          <button
                            type="button"
                            className={`catedras-modal-callBtn ${esLlamado ? 'is-active' : ''}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              setIdDocenteLlamado(String(asignacion.id_docente || ''));
                              setError('');
                            }}
                            title="Marcar como docente llamado a mesa"
                            disabled={guardando || esLlamado}
                          >
                            <FontAwesomeIcon icon={faUserCheck} />
                            {esLlamado ? 'Llamado' : 'Llamar'}
                          </button>
                          <button
                            type="button"
                            className="catedras-modal-asignacionRemove"
                            onClick={(e) => {
                              e.stopPropagation();
                              quitarAsignacion(asignacion.id_docente);
                            }}
                            title="Quitar asignación"
                            disabled={guardando}
                          >
                            <FontAwesomeIcon icon={faTrash} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="cc-emptyState catedras-modal-emptyState">
                  <FontAwesomeIcon icon={faUserSlash} className="cc-emptyIcon" />
                  <div className="cc-emptyText">Todavía no hay docentes asignados a esta cátedra.</div>
                </div>
              )}
            </div>
          </section>
        </div>

        <div className="gm-modal__actions modal-actions catedras-modal-actions">
          <button
            type="button"
            className="gm-btn gm-btn--ghost catedras-modal-removeBtn"
            onClick={quitarTodos}
            disabled={guardando || asignaciones.length === 0}
          >
            <FontAwesomeIcon icon={faUserSlash} />
            Quitar todos
          </button>

          <div className="catedras-modal-actionsRight">
            <button type="button" className="gm-btn gm-btn--ghost" onClick={onCerrar} disabled={guardando}>
              Cancelar
            </button>
            <button type="submit" className="gm-btn gm-btn--primary" disabled={guardando}>
              <FontAwesomeIcon icon={faSave} />
              {guardando ? 'Guardando...' : 'Guardar asignaciones'}
            </button>
          </div>
        </div>

        <ModalContenidoGlobal
          open={Boolean(modalDetalleResumen)}
          title={modalDetalleResumen?.title || 'Detalle'}
          subtitle={modalDetalleResumen?.subtitle || ''}
          content={modalDetalleResumen?.content || ''}
          contentNode={modalDetalleResumen?.contentNode || null}
          contentClassName="ginfo-content--catedrasResumen"
          closeLabel="Cerrar"
          onClose={() => setModalDetalleResumen(null)}
        />
      </form>
    </div>,
    document.body
  );
}
